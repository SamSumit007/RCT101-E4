export const GET_PRODUCTS_LOADING = "products/loading";
export const GET_PRODUCTS_SUCCESS = "products/success";
export const GET_PRODUCTS_ERROR = "products/error";
